export interface MenuItem {
  id: string;
  name: string;
  category: 'tradicionais' | 'especiais' | 'doces' | 'bebidas';
  description: string;
  price: number;
  highlight?: string;
  ingredients: string[];
  image: string;
  spicy?: boolean;
  vegetarian?: boolean;
}

export interface CartItem {
  item: MenuItem;
  quantity: number;
  notes?: string;
}

export interface ReservationFormData {
  name: string;
  phone: string;
  type: 'pedido_entrega' | 'retirada' | 'reserva_mesa';
  peopleCount?: string;
  date?: string;
  time?: string;
  address?: string;
  notes?: string;
}
