export type ConsentStatus = 'unset' | 'accepted' | 'rejected';

const STORAGE_KEY = 'dondudapizzas:consent:v1';
const FONTS_LINK_ID = 'google-fonts-consent';
const FONTS_HREF =
  'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Raleway:ital,wght@0,300..900;1,300..900&display=swap';

/** Lê a escolha salva. O armazenamento pode falhar (modo privado, bloqueio), então tudo é protegido. */
export function readConsent(): ConsentStatus {
  try {
    const value = window.localStorage.getItem(STORAGE_KEY);
    return value === 'accepted' || value === 'rejected' ? value : 'unset';
  } catch {
    return 'unset';
  }
}

export function saveConsent(status: Exclude<ConsentStatus, 'unset'>): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, status);
  } catch {
    /* sem armazenamento: a escolha vale apenas até recarregar a página */
  }
}

export function clearConsent(): void {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* ignorado */
  }
}

/** Carrega o Google Fonts somente depois do consentimento (evita enviar o IP ao Google sem aviso). */
export function loadGoogleFonts(): void {
  if (document.getElementById(FONTS_LINK_ID)) return;
  const link = document.createElement('link');
  link.id = FONTS_LINK_ID;
  link.rel = 'stylesheet';
  link.href = FONTS_HREF;
  document.head.appendChild(link);
}

export function unloadGoogleFonts(): void {
  document.getElementById(FONTS_LINK_ID)?.remove();
}
