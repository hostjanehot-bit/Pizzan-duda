/**
 * Limpa texto digitado pelo cliente antes de montar a mensagem de WhatsApp:
 * remove caracteres de controle, normaliza espaços e limita o tamanho.
 * (O React já escapa o texto na tela; isto protege o conteúdo da mensagem/URL.)
 */
export function cleanText(value: string | undefined, maxLength: number): string {
  if (!value) return '';
  return value
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F​-‏‪-‮⁦-⁩]/g, '')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, maxLength);
}

export const LIMITS = {
  name: 80,
  phone: 20,
  address: 200,
  notes: 500,
  itemNote: 120,
} as const;

/** Mantém só dígitos e símbolos comuns de telefone. */
export function cleanPhone(value: string | undefined): string {
  return cleanText((value ?? '').replace(/[^\d()+\-\s]/g, ''), LIMITS.phone);
}
