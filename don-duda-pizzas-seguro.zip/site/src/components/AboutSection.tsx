import { motion } from 'motion/react';
import { Award, Sparkles, HeartHandshake, Wheat } from 'lucide-react';
import donDudaAmbienceImg from '../assets/images/don_duda_ambience_1793010044770.jpg';

export function AboutSection() {
  const pillars = [
    {
      icon: Wheat,
      title: 'Massa Viva de 48 Horas',
      description: 'Nossa massa descansa por dois dias inteiros sob temperatura controlada. O resultado é leveza inigualável, crocância exterior e digestão perfeita.',
    },
    {
      icon: Sparkles,
      title: 'Tomates San Marzano D.O.P.',
      description: 'Molho puro preparado exclusivamente com tomates italianos colhidos aos pés do Vesúvio, garantindo doçura natural e acidez equilibrada.',
    },
    {
      icon: Award,
      title: 'Forno a Lenha a 450°C',
      description: 'Calor intenso e rápido que sela os aromas e cria o clássico cornicione aerado com as desejadas manchas de leopardo típicas de Nápoles.',
    },
    {
      icon: HeartHandshake,
      title: 'Hospitalidade Capixaba',
      description: 'Mais do que uma refeição, uma celebração para compartilhar entre amigos e famílias no coração da acolhedora Praia da Costa.',
    },
  ];

  return (
    <section id="tradicao" className="py-24 bg-[#0F172A]/90 border-y border-slate-800/80 relative overflow-hidden">
      {/* Decorative subtle ambient warm glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          {/* Left Column: Story Prose */}
          <div className="lg:col-span-6 space-y-6">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-[#E6CA65] uppercase">
              <span>Nossa Tradição & Amor à Mesa</span>
              <span aria-hidden="true" className="text-slate-500">·</span>
              <span>Praia da Costa, ES</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight leading-tight [text-wrap:balance]">
              Onde o tempo é o ingrediente secreto mais valioso.
            </h2>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              A Don Duda nasceu de um desejo genuíno: trazer para Vila Velha a verdadeira experiência da pizza artesanal, onde a pressa dá lugar à paciência e ao respeito absoluto pela matéria-prima.
            </p>

            <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
              Aqui, a lenha crepita no forno todas as noites enquanto o aroma de azeite extravirgem, queijos nobres e manjericão fresco preenche o ambiente. Cada disco que sai da nossa pá é uma obra feita à mão, pensada para transformar qualquer jantar comum em uma ocasião memorável.
            </p>

            {/* Quote Box */}
            <div className="p-6 rounded-2xl bg-[#090D16] border border-[#D4AF37]/20 shadow-inner">
              <p className="text-sm sm:text-base font-serif italic text-[#F3E5AB]">
                “A pizza perfeita não aceita atalhos. Quando o fogo encontra uma massa que descansou 48 horas, o sabor fala por si.”
              </p>
              <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
                <span className="font-semibold text-slate-200">Mestre Pizzaiolo Don Duda</span>
                <span>Vila Velha · Espírito Santo</span>
              </div>
            </div>
          </div>

          {/* Right Column: Ambience Photography */}
          <div className="lg:col-span-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative rounded-3xl overflow-hidden border border-slate-700/60 shadow-2xl group"
            >
              <img
                src={donDudaAmbienceImg}
                alt="Ambiente aconchegante da Don Duda Pizzas na Praia da Costa em Vila Velha"
                referrerPolicy="no-referrer"
                className="w-full h-[460px] object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#090D16] via-transparent to-transparent opacity-80" />
              <div className="absolute bottom-6 left-6 right-6">
                <span className="text-xs font-semibold tracking-wider text-[#D4AF37] uppercase block mb-1">
                  Ambiente Aconchegante
                </span>
                <p className="text-lg font-serif font-bold text-white">
                  O ponto de encontro dos apaixonados por pizza em Vila Velha
                </p>
                <p className="text-xs text-slate-300 mt-1">
                  Rua José Pena Medina, 216 · Praia da Costa
                </p>
              </div>
            </motion.div>
          </div>
        </div>

        {/* 4 Pillars Bento-style Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 pt-4">
          {pillars.map((pillar, idx) => {
            const IconComponent = pillar.icon;
            return (
              <motion.div
                key={pillar.title}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.08 }}
                className="p-6 rounded-2xl bg-[#090D16]/60 border border-slate-800 hover:border-[#D4AF37]/30 transition-all group"
              >
                <div className="w-10 h-10 rounded-xl bg-[#0F172A] border border-slate-700/50 flex items-center justify-center text-[#D4AF37] mb-4 group-hover:border-[#D4AF37]/50 group-hover:scale-110 transition-all">
                  <IconComponent className="w-5 h-5" />
                </div>
                <h3 className="text-base font-serif font-bold text-white mb-2 group-hover:text-[#F3E5AB] transition-colors">
                  {pillar.title}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {pillar.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
