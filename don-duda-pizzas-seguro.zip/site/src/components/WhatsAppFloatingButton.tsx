import { MessageCircle } from 'lucide-react';

export function WhatsAppFloatingButton() {
  const whatsappUrl =
    'https://wa.me/5527997794049?text=Ol%C3%A1%2C+gostaria+de+fazer+um+pedido+ou+tirar+uma+d%C3%BAvida+na+Don+Duda+Pizzas%21';

  return (
    <aside aria-label="Atendimento rápido via WhatsApp" className="fixed bottom-6 right-6 z-40 flex items-center group">
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Falar no WhatsApp da Don Duda Pizzas"
        className="relative flex items-center gap-2.5 px-4 py-3 bg-[#25D366] text-slate-950 font-bold text-xs sm:text-sm rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all duration-300"
      >
        {/* Subtle breathing glow */}
        <span className="absolute -inset-1 rounded-full bg-[#25D366]/40 blur-md -z-10 group-hover:bg-[#25D366]/60 transition-all" />

        <MessageCircle className="w-5 h-5 fill-slate-950" />
        <span className="hidden sm:inline font-semibold text-slate-950">Pedir no WhatsApp</span>
      </a>
    </aside>
  );
}
