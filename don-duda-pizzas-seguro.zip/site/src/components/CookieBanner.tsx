import { motion, AnimatePresence } from 'motion/react';
import { Cookie } from 'lucide-react';

interface CookieBannerProps {
  visible: boolean;
  onAccept: () => void;
  onReject: () => void;
  onOpenPolicy: () => void;
}

export function CookieBanner({ visible, onAccept, onReject, onOpenPolicy }: CookieBannerProps) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          role="dialog"
          aria-label="Aviso de cookies e privacidade"
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 40, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-4 left-4 right-4 sm:left-6 sm:right-auto sm:max-w-md z-[60] p-5 rounded-2xl bg-[#0F172A] border border-[#D4AF37]/30 shadow-2xl"
        >
          <div className="flex items-start gap-3">
            <Cookie className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" aria-hidden="true" />
            <div className="space-y-3">
              <p className="text-xs text-slate-300 leading-relaxed">
                Este site não usa cookies de publicidade nem de rastreamento. Para exibir o <strong className="text-white">mapa</strong> e as{' '}
                <strong className="text-white">fontes</strong> do Google, seus dados de acesso (como o IP) são enviados à Google. Você aceita?{' '}
                <button
                  type="button"
                  onClick={onOpenPolicy}
                  className="underline text-[#E6CA65] hover:text-[#F3E5AB] cursor-pointer"
                >
                  Saiba mais
                </button>
              </p>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={onAccept}
                  className="flex-1 py-2 px-3 rounded-lg text-xs font-bold text-[#090D16] bg-gradient-to-r from-[#E6CA65] to-[#D4AF37] hover:brightness-110 transition cursor-pointer"
                >
                  Aceitar
                </button>
                <button
                  type="button"
                  onClick={onReject}
                  className="flex-1 py-2 px-3 rounded-lg text-xs font-semibold text-slate-200 border border-slate-600 hover:bg-slate-800/60 transition cursor-pointer"
                >
                  Recusar
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
