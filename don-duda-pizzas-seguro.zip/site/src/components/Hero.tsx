import { motion } from 'motion/react';
import { ArrowRight, Flame, MapPin, Clock } from 'lucide-react';
import heroPizzaOvenImg from '../assets/images/hero_pizza_oven_1793010042880.jpg';

interface HeroProps {
  onOpenOrderModal: () => void;
}

export function Hero({ onOpenOrderModal }: HeroProps) {
  return (
    <section id="inicio" className="relative min-h-[92vh] flex flex-col justify-between pt-28 pb-12 overflow-hidden">
      {/* Background with measured contrast scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroPizzaOvenImg}
          alt="Pizza artesanal assando no forno a lenha na Don Duda em Vila Velha"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-105 transform brightness-[0.42] contrast-[1.12]"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#090D16]/85 via-[#090D16]/65 to-[#090D16]" />
        <div className="absolute inset-0 bg-radial from-transparent via-[#090D16]/40 to-[#090D16]" />
      </div>

      {/* Main Hero Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex-1 flex flex-col justify-center my-auto">
        <div className="max-w-3xl">
          {/* Unboxed editorial kicker - NO pills */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex items-center gap-2 text-xs sm:text-sm font-semibold tracking-wider text-[#E6CA65] uppercase mb-4"
          >
            <Flame className="w-4 h-4 text-[#D4AF37]" />
            <span>Pizzaria Artesanal</span>
            <span aria-hidden="true" className="text-slate-500">·</span>
            <span>Praia da Costa, Vila Velha</span>
            <span aria-hidden="true" className="text-slate-500">·</span>
            <span>Forno a Lenha</span>
          </motion.div>

          {/* Slogan & Headline: clamp 48-96px with balance */}
          <motion.h1
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="text-4xl sm:text-6xl lg:text-7xl font-serif font-bold text-white tracking-tight leading-[1.08] mb-6 [text-wrap:balance]"
          >
            Fornadas vivas onde a tradição italiana encontra a brisa de <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#E6CA65]">Vila Velha</span>.
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.16, ease: [0.16, 1, 0.3, 1] }}
            className="text-base sm:text-xl text-slate-300 font-normal leading-relaxed max-w-2xl mb-8"
          >
            Massa de fermentação natural maturada por 48 horas, tomates San Marzano D.O.P. e queijos artesanais nobres. Textura crocante e macia assada no calor vivo a mais de 450°C.
          </motion.p>

          {/* Action CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.24, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4"
          >
            <a
              href="#cardapio"
              className="inline-flex items-center justify-center gap-3 px-8 py-4 text-base font-semibold text-[#090D16] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#B89225] rounded-xl hover:brightness-110 active:scale-95 transition-all shadow-xl gold-glow whitespace-nowrap cursor-pointer"
            >
              <span>Explorar Cardápio Digital</span>
              <ArrowRight className="w-5 h-5 text-[#090D16]" />
            </a>

            <button
              onClick={onOpenOrderModal}
              type="button"
              className="inline-flex items-center justify-center gap-2 px-7 py-4 text-base font-medium text-slate-200 hover:text-white bg-[#0F172A]/80 hover:bg-[#141B2D] border border-slate-700/60 hover:border-[#D4AF37]/40 rounded-xl transition-all whitespace-nowrap cursor-pointer"
            >
              <span>Entrar em contato</span>
            </button>
          </motion.div>

          {/* Micro trust meta */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.32 }}
            className="mt-6 flex flex-wrap items-center gap-4 text-xs text-slate-400"
          >
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>R. José Pena Medina, 216 - Praia da Costa</span>
            </div>
            <span aria-hidden="true" className="text-slate-600 hidden sm:inline">·</span>
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Terça a Domingo das 18h às 23h30</span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Proof Strip / KPI metrics - Full width 4-column strip */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full mt-12">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 p-6 sm:p-8 rounded-2xl bg-[#0F172A]/80 border border-slate-800/80 backdrop-blur-xl shadow-2xl"
        >
          <div className="flex flex-col">
            <span className="text-2xl sm:text-4xl font-serif font-bold text-[#F3E5AB] tabular-nums">48 Horas</span>
            <span className="text-xs sm:text-sm text-slate-300 mt-1 font-medium">Fermentação lenta natural</span>
            <span className="text-[11px] text-slate-400 mt-0.5">Digestão leve e borda aerada</span>
          </div>

          <div className="flex flex-col border-l border-slate-800/80 pl-4 sm:pl-6">
            <span className="text-2xl sm:text-4xl font-serif font-bold text-[#F3E5AB] tabular-nums">450°C</span>
            <span className="text-xs sm:text-sm text-slate-300 mt-1 font-medium">Forno a lenha autêntico</span>
            <span className="text-[11px] text-slate-400 mt-0.5">Assamento em 90 segundos</span>
          </div>

          <div className="flex flex-col border-l-0 lg:border-l border-slate-800/80 pt-4 lg:pt-0 pl-0 lg:pl-6">
            <span className="text-2xl sm:text-4xl font-serif font-bold text-[#F3E5AB] tabular-nums">4.9 ★</span>
            <span className="text-xs sm:text-sm text-slate-300 mt-1 font-medium">Avaliações no Google Maps</span>
            <span className="text-[11px] text-slate-400 mt-0.5">Mais elogiada da Praia da Costa</span>
          </div>

          <div className="flex flex-col border-l border-slate-800/80 pt-4 lg:pt-0 pl-4 sm:pl-6">
            <span className="text-2xl sm:text-4xl font-serif font-bold text-[#F3E5AB] tabular-nums">+3.500</span>
            <span className="text-xs sm:text-sm text-slate-300 mt-1 font-medium">Pizzas entregues ao mês</span>
            <span className="text-[11px] text-slate-400 mt-0.5">Embalagem térmica selada</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
