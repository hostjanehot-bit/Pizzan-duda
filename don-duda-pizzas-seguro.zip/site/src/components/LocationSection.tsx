import { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Navigation, Clock, Check, Copy, Car, ShieldCheck } from 'lucide-react';

interface LocationSectionProps {
  mapsAllowed: boolean;
  onAllowMaps: () => void;
}

export function LocationSection({ mapsAllowed, onAllowMaps }: LocationSectionProps) {
  const [copied, setCopied] = useState(false);
  const fullAddress = 'R. José Pena Medina, 216 - Praia da Costa, Vila Velha - ES, 29101-320';
  const googleMapsUrl = 'https://maps.google.com/?cid=14851345992558105311&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA';

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(fullAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="localizacao" className="py-24 bg-[#090D16] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold tracking-wider text-[#E6CA65] uppercase mb-2">
            <MapPin className="w-4 h-4 text-[#D4AF37]" />
            <span>Localização Privilegiada</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Praia da Costa</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight [text-wrap:balance]">
            Venha nos visitar no coração de Vila Velha
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            Localização charmosa, ambiente climatizado, mesas confortáveis e fácil acesso para moradores e turistas da Praia da Costa.
          </p>
        </div>

        {/* 2-Column Split: Map on Left, Details & Delivery info on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Map Preview Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-7 rounded-3xl overflow-hidden border border-slate-800 bg-[#0F172A] shadow-2xl flex flex-col justify-between"
          >
            <div className="relative w-full h-[360px] sm:h-[420px] bg-slate-900">
              {mapsAllowed ? (
                <iframe
                  title="Mapa de Localização da Don Duda Pizzas em Vila Velha"
                  src="https://maps.google.com/maps?q=R.+Jos%C3%A9+Pena+Medina,+216+-+Praia+da+Costa,+Vila+Velha+-+ES&t=&z=16&ie=UTF8&iwloc=&output=embed"
                  className="w-full h-full border-0 filter grayscale contrast-125 brightness-90 hover:grayscale-0 transition-all duration-500"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center gap-3 p-6 text-center">
                  <MapPin className="w-8 h-8 text-[#D4AF37]" aria-hidden="true" />
                  <p className="text-xs text-slate-300 max-w-xs leading-relaxed">
                    O mapa é fornecido pelo Google e só é carregado com a sua permissão, pois o Google recebe seu IP e pode definir cookies.
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={onAllowMaps}
                      className="px-4 py-2 rounded-lg text-xs font-bold text-[#090D16] bg-gradient-to-r from-[#E6CA65] to-[#D4AF37] hover:brightness-110 transition cursor-pointer"
                    >
                      Carregar mapa
                    </button>
                    <a
                      href={googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-200 border border-slate-600 hover:bg-slate-800/60 transition"
                    >
                      Abrir no Google Maps
                    </a>
                  </div>
                </div>
              )}
              <div className="absolute top-4 left-4 bg-[#090D16]/90 backdrop-blur-md px-3.5 py-1.5 rounded-lg border border-[#D4AF37]/30 text-xs font-medium text-white flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-ping" />
                <span>Don Duda · Salão & Balcão</span>
              </div>
            </div>

            <div className="p-6 bg-[#0F172A] border-t border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="text-xs text-slate-300">
                <span className="font-semibold text-white block">R. José Pena Medina, 216</span>
                <span>Praia da Costa, Vila Velha - ES · CEP 29101-320</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyAddress}
                  className="px-3.5 py-2 text-xs font-medium text-slate-300 hover:text-white bg-[#141B2D] border border-slate-700/80 rounded-lg hover:border-slate-600 transition-all flex items-center gap-1.5 cursor-pointer"
                  title="Copiar endereço completo"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copiado!' : 'Copiar Endereço'}</span>
                </button>

                <a
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 text-xs font-semibold text-[#090D16] bg-gradient-to-r from-[#E6CA65] to-[#D4AF37] rounded-lg hover:brightness-110 transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Navigation className="w-3.5 h-3.5 text-[#090D16]" />
                  <span>Abrir no GPS</span>
                </a>
              </div>
            </div>
          </motion.div>

          {/* Details & Delivery Radius */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-5 flex flex-col justify-between gap-6"
          >
            {/* Opening Hours Box */}
            <div className="p-6 rounded-2xl bg-[#0F172A] border border-slate-800 space-y-4">
              <div className="flex items-center gap-2.5 text-[#F3E5AB]">
                <Clock className="w-5 h-5 text-[#D4AF37]" />
                <h3 className="text-base font-serif font-bold text-white">Horário de Funcionamento</h3>
              </div>
              <ul className="space-y-2.5 text-xs sm:text-sm text-slate-300">
                <li className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-400">Terça a Quinta-feira</span>
                  <span className="font-semibold text-white">18:00 às 23:30</span>
                </li>
                <li className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-400">Sexta e Sábado</span>
                  <span className="font-semibold text-[#F3E5AB]">18:00 às 00:00</span>
                </li>
                <li className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-400">Domingo</span>
                  <span className="font-semibold text-white">18:00 às 23:30</span>
                </li>
                <li className="flex justify-between py-1 text-slate-400">
                  <span>Segunda-feira</span>
                  <span className="text-rose-400 font-medium">Fechado para descanso da massa</span>
                </li>
              </ul>
            </div>

            {/* Delivery coverage card */}
            <div className="p-6 rounded-2xl bg-[#0F172A] border border-slate-800 space-y-3">
              <div className="flex items-center gap-2 text-[#F3E5AB]">
                <Car className="w-5 h-5 text-[#D4AF37]" />
                <h3 className="text-base font-serif font-bold text-white">Raio de Entrega Rápida</h3>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Entregamos com caixas térmicas e lacre de segurança em toda a região de Vila Velha:
              </p>
              <div className="flex flex-wrap gap-2 pt-1">
                {['Praia da Costa', 'Itapuã', 'Praia de Itaparica', 'Centro de Vila Velha', 'Glória', 'Jaburuna'].map(
                  (bairro) => (
                    <span
                      key={bairro}
                      className="text-xs text-slate-300 bg-[#161F33] px-3 py-1 rounded-md border border-slate-800"
                    >
                      {bairro}
                    </span>
                  )
                )}
              </div>
            </div>

            {/* Quality assurance guarantee */}
            <div className="p-5 rounded-2xl bg-[#0F172A]/60 border border-[#D4AF37]/20 flex items-center gap-4">
              <ShieldCheck className="w-8 h-8 text-[#D4AF37] shrink-0" />
              <div className="text-xs">
                <span className="font-semibold text-white block">Garantia de Pizza Quente</span>
                <span className="text-slate-400">
                  Sua pizza chega quentinha e com a massa crocante, como se tivesse saído do forno no seu prato.
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
