import { useState, useEffect } from 'react';
import { ShoppingBag, Menu, X, PhoneCall } from 'lucide-react';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenOrderModal: () => void;
}

export function Navbar({ cartCount, onOpenCart, onOpenOrderModal }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Início', href: '#inicio' },
    { name: 'Cardápio', href: '#cardapio' },
    { name: 'Tradição', href: '#tradicao' },
    { name: 'Localização', href: '#localizacao' },
    { name: 'Contato', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#090D16]/90 backdrop-blur-md border-b border-[#D4AF37]/20 shadow-2xl py-3.5'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8">
          {/* Zone 1: Single text element wordmark */}
          <a
            href="#inicio"
            className="text-2xl sm:text-3xl font-serif tracking-tight text-white font-bold whitespace-nowrap shrink-0 group flex items-center gap-2"
          >
            <span>Don Duda</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] transition-transform duration-300 group-hover:scale-150" />
          </a>

          {/* Zone 2: 4–5 clean single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="hover:text-[#F3E5AB] transition-colors whitespace-nowrap shrink-0 tracking-wide hover:underline underline-offset-8 decoration-[#D4AF37]/50"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenCart}
              type="button"
              className="relative p-2.5 rounded-lg border border-slate-700/60 hover:border-[#D4AF37]/50 bg-[#0F172A]/70 text-slate-200 hover:text-[#F3E5AB] transition-all flex items-center gap-2 cursor-pointer"
              title="Sacola de Pedidos"
              aria-label="Abrir sacola de pedidos"
            >
              <ShoppingBag className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-xs font-semibold tabular-nums">
                {cartCount > 0 ? (
                  <span className="text-[#F3E5AB]">{cartCount}</span>
                ) : (
                  <span className="hidden sm:inline text-slate-400">0</span>
                )}
              </span>
            </button>

            <button
              onClick={onOpenOrderModal}
              type="button"
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-[#090D16] bg-gradient-to-r from-[#E6CA65] via-[#D4AF37] to-[#B89225] rounded-lg hover:brightness-110 active:scale-95 transition-all shadow-md gold-glow-subtle whitespace-nowrap shrink-0 cursor-pointer"
            >
              Fazer Pedido
            </button>

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              type="button"
              className="md:hidden p-2 text-slate-300 hover:text-white rounded-lg border border-slate-700/60 bg-[#0F172A]/60 cursor-pointer"
              aria-label="Menu de navegação"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#090D16]/98 border-b border-[#D4AF37]/20 px-6 py-6 shadow-2xl backdrop-blur-xl animate-in slide-in-from-top-2 duration-200">
          <div className="flex flex-col gap-4 text-base font-medium">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="py-2 text-slate-200 hover:text-[#D4AF37] transition-colors border-b border-slate-800/60"
              >
                {link.name}
              </a>
            ))}
            <div className="pt-2 flex flex-col gap-3">
              <a
                href="tel:+5527997794049"
                className="flex items-center justify-center gap-2 py-3 rounded-lg border border-[#D4AF37]/40 text-sm font-medium text-[#F3E5AB] hover:bg-[#D4AF37]/10"
              >
                <PhoneCall className="w-4 h-4 text-[#D4AF37]" />
                (27) 99779-4049
              </a>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenOrderModal();
                }}
                className="w-full py-3 text-center text-sm font-bold text-[#090D16] bg-gradient-to-r from-[#E6CA65] to-[#D4AF37] rounded-lg shadow-lg"
              >
                Entrar em Contato
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
