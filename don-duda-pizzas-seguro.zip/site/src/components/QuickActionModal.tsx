import { motion, AnimatePresence } from 'motion/react';
import { X, UtensilsCrossed, MessageCircle, CalendarCheck, PhoneCall } from 'lucide-react';

interface QuickActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGoToMenu: () => void;
  onGoToContact: () => void;
}

export function QuickActionModal({
  isOpen,
  onClose,
  onGoToMenu,
  onGoToContact,
}: QuickActionModalProps) {
  const whatsappUrl =
    'https://wa.me/5527997794049?text=Ol%C3%A1%2C+gostaria+de+fazer+um+pedido+na+Don+Duda+Pizzas%21';

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            className="bg-[#0F172A] border border-[#D4AF37]/30 rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl relative"
          >
            <button
              onClick={onClose}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-white bg-[#090D16]/60 border border-slate-800"
              aria-label="Fechar"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center mb-6">
              <span className="text-xs uppercase tracking-wider text-[#D4AF37] font-semibold block mb-1">
                Atendimento Don Duda Pizzas
              </span>
              <h3 className="text-2xl font-serif font-bold text-white">
                Como prefere fazer seu pedido?
              </h3>
              <p className="text-xs text-slate-400 mt-2">
                Escolha a forma mais conveniente para você hoje.
              </p>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  onClose();
                  onGoToMenu();
                }}
                className="w-full p-4 rounded-2xl bg-gradient-to-r from-[#E6CA65] to-[#D4AF37] text-[#090D16] font-bold text-sm flex items-center justify-between shadow-lg hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-black/10 flex items-center justify-center">
                    <UtensilsCrossed className="w-5 h-5 text-[#090D16]" />
                  </div>
                  <div className="text-left">
                    <span className="block leading-tight">Escolher no Cardápio Digital</span>
                    <span className="text-[11px] font-normal text-slate-900/80">
                      Monte sua sacola com fotos e preços
                    </span>
                  </div>
                </div>
                <span className="text-xs font-black">→</span>
              </button>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={onClose}
                className="w-full p-4 rounded-2xl bg-[#141B2D] border border-emerald-600/40 hover:border-emerald-500 text-white font-semibold text-sm flex items-center justify-between hover:bg-[#1a233a] transition-all cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-950/70 text-emerald-400 flex items-center justify-center border border-emerald-700/50">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <span className="block text-white leading-tight">Pedir Direto pelo WhatsApp</span>
                    <span className="text-[11px] text-slate-400 font-normal">
                      (27) 99779-4049 · Atendimento ágil
                    </span>
                  </div>
                </div>
                <span className="text-xs text-emerald-400">Abrir</span>
              </a>

              <button
                onClick={() => {
                  onClose();
                  onGoToContact();
                }}
                className="w-full p-4 rounded-2xl bg-[#141B2D] border border-slate-800 hover:border-slate-700 text-white font-semibold text-sm flex items-center justify-between hover:bg-[#1a233a] transition-all cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#090D16] text-[#D4AF37] flex items-center justify-center border border-slate-800">
                    <CalendarCheck className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <span className="block text-white leading-tight">Reservar Mesa no Salão</span>
                    <span className="text-[11px] text-slate-400 font-normal">
                      Praia da Costa · Ambiente climatizado
                    </span>
                  </div>
                </div>
                <span className="text-xs text-slate-400">Ver</span>
              </button>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 text-center">
              <a
                href="tel:+5527997794049"
                className="inline-flex items-center gap-2 text-xs text-slate-400 hover:text-[#F3E5AB] transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Preferir ligar? +55 27 99779-4049</span>
              </a>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
