import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Trash2, Plus, Minus, Send, ShoppingBag, Bike, Store } from 'lucide-react';
import { CartItem } from '../types';
import { LIMITS, cleanPhone, cleanText } from '../lib/sanitize';

interface OrderDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (itemId: string, newQty: number) => void;
  onRemoveItem: (itemId: string) => void;
  onClearCart: () => void;
  onOpenPolicy: () => void;
}

export function OrderDrawer({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOpenPolicy,
}: OrderDrawerProps) {
  const [orderType, setOrderType] = useState<'delivery' | 'retirada'>('delivery');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [generalNotes, setGeneralNotes] = useState('');
  const [formError, setFormError] = useState('');

  const subtotal = items.reduce((acc, current) => acc + current.item.price * current.quantity, 0);
  const deliveryFee = orderType === 'delivery' && items.length > 0 ? 8.0 : 0.0;
  const grandTotal = subtotal + deliveryFee;

  const handleSendWhatsApp = () => {
    const name = cleanText(customerName, LIMITS.name);
    const phone = cleanPhone(customerPhone);
    const address = cleanText(customerAddress, LIMITS.address);
    const notes = cleanText(generalNotes, LIMITS.notes);

    if (!name) {
      setFormError('Por favor, informe seu nome para o pedido.');
      return;
    }
    if (orderType === 'delivery' && !address) {
      setFormError('Por favor, informe o endereço de entrega em Vila Velha.');
      return;
    }

    setFormError('');

    // Format WhatsApp message in Brazilian Portuguese
    const itemListText = items
      .map(
        (ci) =>
          `• ${ci.quantity}x ${ci.item.name} (R$ ${(ci.item.price * ci.quantity).toFixed(2).replace('.', ',')})${
            ci.notes ? `\n   Obs: ${ci.notes}` : ''
          }`
      )
      .join('\n');

    const message = `🍕 *NOVO PEDIDO - DON DUDA PIZZAS*\n\n` +
      `*Cliente:* ${name}\n` +
      (phone ? `*Telefone:* ${phone}\n` : '') +
      `*Tipo:* ${orderType === 'delivery' ? '🛵 Entrega (Delivery)' : '🏬 Retirada no Balcão'}\n` +
      (orderType === 'delivery' ? `*Endereço:* ${address}\n` : '') +
      `\n*ITENS SELECIONADOS:*\n${itemListText}\n\n` +
      `*Subtotal:* R$ ${subtotal.toFixed(2).replace('.', ',')}\n` +
      (orderType === 'delivery' ? `*Taxa de Entrega estimada:* R$ ${deliveryFee.toFixed(2).replace('.', ',')}\n` : '') +
      `*TOTAL:* R$ ${grandTotal.toFixed(2).replace('.', ',')}\n` +
      (notes ? `\n*Observações Gerais:* ${notes}\n` : '') +
      `\nEnviado através do Cardápio Digital Don Duda`;

    const encoded = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/5527997794049?text=${encoded}`;
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/75 backdrop-blur-sm"
          />

          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              className="w-screen max-w-md bg-[#0F172A] border-l border-slate-800 shadow-2xl flex flex-col"
            >
              {/* Header */}
              <div className="p-6 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
                  <h3 className="text-xl font-serif font-bold text-white">Sua Sacola de Pedidos</h3>
                </div>
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  aria-label="Fechar sacola"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Items List */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {items.length === 0 ? (
                  <div className="text-center py-16">
                    <ShoppingBag className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <p className="text-base font-serif text-slate-300">Sua sacola está vazia</p>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                      Explore nosso cardápio e adicione suas pizzas e bebidas favoritas.
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800">
                      <span>Itens adicionados ({items.reduce((s, i) => s + i.quantity, 0)})</span>
                      <button
                        onClick={onClearCart}
                        className="text-red-400 hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Limpar sacola
                      </button>
                    </div>

                    {items.map((cartItem) => (
                      <div
                        key={cartItem.item.id}
                        className="p-4 rounded-xl bg-[#141B2D] border border-slate-800/80 space-y-3"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h4 className="text-sm font-semibold text-white">{cartItem.item.name}</h4>
                            <span className="text-xs text-[#F3E5AB] tabular-nums">
                              R$ {(cartItem.item.price * cartItem.quantity).toFixed(2).replace('.', ',')}
                            </span>
                          </div>

                          {/* Quantity control */}
                          <div className="flex items-center gap-2 bg-[#090D16] px-2 py-1 rounded-lg border border-slate-800">
                            <button
                              onClick={() => onUpdateQuantity(cartItem.item.id, cartItem.quantity - 1)}
                              className="text-slate-400 hover:text-white p-1"
                              aria-label="Diminuir quantidade"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-xs font-semibold text-white tabular-nums px-1">
                              {cartItem.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQuantity(cartItem.item.id, cartItem.quantity + 1)}
                              className="text-slate-400 hover:text-white p-1"
                              aria-label="Aumentar quantidade"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>

                        {cartItem.notes && (
                          <p className="text-[11px] text-slate-400 italic bg-[#090D16]/60 p-2 rounded-md">
                            Obs: {cartItem.notes}
                          </p>
                        )}
                      </div>
                    ))}

                    {/* Delivery or Pickup toggle */}
                    <div className="pt-4 space-y-3">
                      <label className="block text-xs uppercase tracking-wider text-slate-400 font-semibold">
                        Forma de Atendimento
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setOrderType('delivery')}
                          className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                            orderType === 'delivery'
                              ? 'bg-[#D4AF37]/20 border-[#D4AF37] text-[#F3E5AB]'
                              : 'bg-[#141B2D] border-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          <Bike className="w-4 h-4" />
                          <span>Entrega (Delivery)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setOrderType('retirada')}
                          className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                            orderType === 'retirada'
                              ? 'bg-[#D4AF37]/20 border-[#D4AF37] text-[#F3E5AB]'
                              : 'bg-[#141B2D] border-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          <Store className="w-4 h-4" />
                          <span>Retirada Balcão</span>
                        </button>
                      </div>
                    </div>

                    {/* Customer Info Form inside Drawer */}
                    <div className="space-y-3 pt-2">
                      <div>
                        <label className="block text-xs text-slate-300 mb-1">Seu Nome *</label>
                        <input
                          type="text"
                          maxLength={LIMITS.name}
                          autoComplete="name"
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="Ex: Carlos Silva"
                          className="w-full px-3 py-2 bg-[#090D16] border border-slate-800 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37]"
                        />
                      </div>

                      {orderType === 'delivery' && (
                        <div>
                          <label className="block text-xs text-slate-300 mb-1">Endereço de Entrega *</label>
                          <input
                            type="text"
                            maxLength={LIMITS.address}
                            autoComplete="street-address"
                            value={customerAddress}
                            onChange={(e) => setCustomerAddress(e.target.value)}
                            placeholder="Rua, número, complemento e bairro (Vila Velha)"
                            className="w-full px-3 py-2 bg-[#090D16] border border-slate-800 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37]"
                          />
                        </div>
                      )}

                      <div>
                        <label className="block text-xs text-slate-300 mb-1">Telefone / WhatsApp (Opcional)</label>
                        <input
                          type="tel"
                          maxLength={LIMITS.phone}
                          autoComplete="tel"
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          placeholder="(27) 99999-9999"
                          className="w-full px-3 py-2 bg-[#090D16] border border-slate-800 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs text-slate-300 mb-1">Observações gerais</label>
                        <input
                          type="text"
                          maxLength={LIMITS.notes}
                          value={generalNotes}
                          onChange={(e) => setGeneralNotes(e.target.value)}
                          placeholder="Ex: pagar no cartão de crédito na entrega"
                          className="w-full px-3 py-2 bg-[#090D16] border border-slate-800 rounded-lg text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37]"
                        />
                      </div>

                      <p className="text-[11px] text-slate-500 leading-relaxed">
                        Seus dados são usados só para montar a mensagem do pedido (veja a{' '}
                        <button
                          type="button"
                          onClick={onOpenPolicy}
                          className="underline text-[#E6CA65] hover:text-[#F3E5AB] cursor-pointer"
                        >
                          Política de Privacidade
                        </button>
                        ).
                      </p>

                      {formError && (
                        <p className="text-xs text-rose-400 font-medium bg-rose-950/40 border border-rose-800/60 p-2 rounded-lg">
                          {formError}
                        </p>
                      )}
                    </div>
                  </>
                )}
              </div>

              {/* Bottom Summary & WhatsApp Checkout */}
              {items.length > 0 && (
                <div className="p-6 border-t border-slate-800 bg-[#090D16]/80 space-y-4">
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between text-slate-400">
                      <span>Subtotal dos itens</span>
                      <span className="tabular-nums font-medium text-slate-200">
                        R$ {subtotal.toFixed(2).replace('.', ',')}
                      </span>
                    </div>
                    {orderType === 'delivery' && (
                      <div className="flex justify-between text-slate-400">
                        <span>Taxa de Entrega estimada</span>
                        <span className="tabular-nums font-medium text-slate-200">
                          R$ {deliveryFee.toFixed(2).replace('.', ',')}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between text-base font-serif font-bold text-white pt-2 border-t border-slate-800">
                      <span>Total Geral</span>
                      <span className="text-[#F3E5AB] tabular-nums">
                        R$ {grandTotal.toFixed(2).replace('.', ',')}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={handleSendWhatsApp}
                    className="w-full py-3.5 px-4 rounded-xl font-bold text-[#090D16] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#B89225] hover:brightness-110 active:scale-[0.98] transition-all shadow-lg gold-glow flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Send className="w-4 h-4 text-[#090D16]" />
                    <span>Enviar Pedido via WhatsApp</span>
                  </button>

                  <p className="text-[11px] text-center text-slate-400">
                    Atendimento Don Duda: (27) 99779-4049 · Praia da Costa
                  </p>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
}
