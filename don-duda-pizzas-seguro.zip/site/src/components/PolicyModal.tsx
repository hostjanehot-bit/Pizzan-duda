import { useEffect, useRef, type ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';

export type PolicyTab = 'privacidade' | 'cookies';

interface PolicyModalProps {
  isOpen: boolean;
  tab: PolicyTab;
  onTabChange: (tab: PolicyTab) => void;
  onClose: () => void;
  onChangeCookiePreferences: () => void;
}

const UPDATED_AT = '26 de outubro de 2026';
const WHATSAPP_LABEL = '(27) 99779-4049';

function H({ children }: { children: ReactNode }) {
  return <h4 className="text-sm font-bold text-white mt-6 mb-2">{children}</h4>;
}

function PrivacyContent() {
  return (
    <div className="space-y-2 text-xs sm:text-sm text-slate-300 leading-relaxed">
      <p>
        Esta Política explica como a <strong className="text-white">Don Duda Pizzas</strong> (R. José Pena Medina, 216 - Praia da Costa, Vila Velha - ES, 29101-320)
        trata dados pessoais neste site, em conformidade com a Lei Geral de Proteção de Dados (Lei nº 13.709/2018 – LGPD).
      </p>

      <H>1. Quem é o controlador</H>
      <p>
        A Don Duda Pizzas é a responsável pelas decisões sobre o tratamento dos seus dados. Contato para qualquer assunto sobre privacidade: WhatsApp/telefone{' '}
        {WHATSAPP_LABEL}, ou presencialmente no endereço acima.
      </p>

      <H>2. Quais dados coletamos</H>
      <p>Coletamos apenas o que você digita nos formulários do site, quando decide usá-los:</p>
      <ul className="list-disc pl-5 space-y-1">
        <li>
          <strong className="text-white">Formulário de contato/reserva:</strong> nome, telefone, tipo de atendimento, data, horário, número de pessoas e observações.
        </li>
        <li>
          <strong className="text-white">Sacola de pedidos:</strong> itens escolhidos, nome, telefone (opcional), endereço de entrega (para delivery) e observações.
        </li>
      </ul>
      <p>
        <strong className="text-white">Importante:</strong> este site não possui servidor nem banco de dados próprios. Os dados dos formulários ficam apenas na memória do seu navegador e
        são perdidos ao fechar ou recarregar a página. Eles só saem do seu dispositivo quando você clica para enviar a mensagem pelo WhatsApp.
      </p>
      <p>
        Dados técnicos (como endereço IP e tipo de navegador) podem ser recebidos pelo provedor de hospedagem do site e, se você aceitar, pelo Google (veja a seção 5).
      </p>

      <H>3. Para que usamos e qual a base legal</H>
      <ul className="list-disc pl-5 space-y-1">
        <li>
          Montar e enviar seu pedido, reserva ou pedido de contato e entregar o que você solicitou – execução de contrato ou de procedimentos preliminares a pedido do titular
          (art. 7º, V da LGPD).
        </li>
        <li>Responder dúvidas que você nos enviar – legítimo interesse e atendimento à sua solicitação (art. 7º, IX).</li>
        <li>Exibir o mapa e as fontes do Google – seu consentimento (art. 7º, I), que você pode recusar ou retirar a qualquer momento.</li>
      </ul>
      <p>Não usamos seus dados para publicidade, perfilamento nem os vendemos a terceiros.</p>

      <H>4. Com quem os dados são compartilhados</H>
      <ul className="list-disc pl-5 space-y-1">
        <li>
          <strong className="text-white">WhatsApp (Meta Platforms):</strong> ao clicar em enviar, o aplicativo abre com a mensagem pronta e o envio passa a seguir os termos e a política de
          privacidade do WhatsApp.
        </li>
        <li>
          <strong className="text-white">Google (mapa e fontes):</strong> somente se você aceitar os cookies/recursos de terceiros.
        </li>
        <li>
          <strong className="text-white">Provedor de hospedagem:</strong> recebe os registros técnicos de acesso necessários para entregar o site.
        </li>
        <li>Autoridades, quando houver obrigação legal ou ordem judicial.</li>
      </ul>
      <p>
        Alguns desses serviços podem armazenar dados fora do Brasil. Nesses casos, a transferência ocorre conforme o art. 33 da LGPD.
      </p>

      <H>5. Mapa e fontes do Google</H>
      <p>
        O mapa de localização e as fontes de texto são carregados dos servidores do Google. Ao carregá-los, o Google recebe seu IP e informações do navegador e pode definir cookies. Por isso,
        esses recursos só são carregados <strong className="text-white">depois que você aceita</strong> no aviso de cookies. Se recusar, o site funciona normalmente, com fontes padrão do
        sistema e um botão para abrir a localização no Google Maps.
      </p>

      <H>6. Por quanto tempo guardamos</H>
      <p>
        O site não armazena seus dados. As conversas iniciadas por WhatsApp ficam no aparelho e na conta do estabelecimento pelo tempo necessário para atender o pedido, cumprir obrigações
        legais e resolver eventuais reclamações; depois disso são eliminadas.
      </p>

      <H>7. Seus direitos</H>
      <p>Você pode solicitar, a qualquer momento (art. 18 da LGPD):</p>
      <ul className="list-disc pl-5 space-y-1">
        <li>confirmação de que tratamos seus dados e acesso a eles;</li>
        <li>correção de dados incompletos, inexatos ou desatualizados;</li>
        <li>anonimização, bloqueio ou eliminação de dados desnecessários ou tratados em desconformidade;</li>
        <li>informação sobre com quem compartilhamos seus dados;</li>
        <li>eliminação dos dados tratados com base no consentimento e retirada do consentimento;</li>
        <li>revisão de decisões e oposição a tratamentos, quando cabível.</li>
      </ul>
      <p>
        Faça o pedido pelo WhatsApp {WHATSAPP_LABEL}. Você também pode reclamar à Autoridade Nacional de Proteção de Dados (ANPD) em gov.br/anpd.
      </p>

      <H>8. Segurança</H>
      <p>
        O site é servido por conexão criptografada (HTTPS), não grava dados pessoais em servidor próprio e usa cabeçalhos de segurança do navegador. Nenhum sistema é 100% seguro; por isso,
        evite digitar no campo de observações informações sensíveis, como dados de cartão, senhas ou documentos. <strong className="text-white">Nunca pedimos dados de cartão por este site.</strong>
      </p>

      <H>9. Crianças e adolescentes</H>
      <p>O site não é direcionado a menores de 18 anos. Menores devem usar os formulários acompanhados de um responsável.</p>

      <H>10. Alterações</H>
      <p>Podemos atualizar esta Política. A data da última atualização aparece no topo desta janela.</p>
    </div>
  );
}

function CookiesContent({ onChangePreferences }: { onChangePreferences: () => void }) {
  return (
    <div className="space-y-2 text-xs sm:text-sm text-slate-300 leading-relaxed">
      <p>
        Cookies são pequenos arquivos que um site ou serviço grava no seu navegador. Esta Política explica quais recursos deste site podem usar cookies ou tecnologias semelhantes.
      </p>

      <H>1. O que este site grava no seu navegador</H>
      <div className="overflow-x-auto rounded-xl border border-slate-800">
        <table className="w-full text-left text-xs">
          <thead className="bg-[#141B2D] text-slate-200">
            <tr>
              <th className="p-3 font-semibold">Item</th>
              <th className="p-3 font-semibold">Quem define</th>
              <th className="p-3 font-semibold">Finalidade</th>
              <th className="p-3 font-semibold">Categoria</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            <tr>
              <td className="p-3 text-white">dondudapizzas:consent:v1 (armazenamento local)</td>
              <td className="p-3">Don Duda Pizzas</td>
              <td className="p-3">Lembrar sua escolha neste aviso. Não identifica você.</td>
              <td className="p-3">Estritamente necessário</td>
            </tr>
            <tr>
              <td className="p-3 text-white">Fontes do Google (fonts.googleapis.com)</td>
              <td className="p-3">Google</td>
              <td className="p-3">Exibir as fontes do site. Só carrega com seu aceite.</td>
              <td className="p-3">Funcional / terceiros</td>
            </tr>
            <tr>
              <td className="p-3 text-white">Mapa incorporado (maps.google.com)</td>
              <td className="p-3">Google</td>
              <td className="p-3">Exibir a localização da pizzaria. Só carrega com seu aceite e pode definir cookies do Google.</td>
              <td className="p-3">Funcional / terceiros</td>
            </tr>
          </tbody>
        </table>
      </div>

      <H>2. O que não usamos</H>
      <p>Não usamos cookies de publicidade, de análise de audiência (como Google Analytics), pixels de redes sociais nem ferramentas de rastreamento entre sites.</p>

      <H>3. Como gerenciar suas preferências</H>
      <p>
        Você pode mudar de ideia quando quiser:{' '}
        <button
          type="button"
          onClick={onChangePreferences}
          className="underline text-[#E6CA65] hover:text-[#F3E5AB] cursor-pointer"
        >
          alterar minhas preferências de cookies
        </button>
        . Também é possível bloquear ou apagar cookies nas configurações do navegador; isso pode afetar o funcionamento de alguns recursos de terceiros, como o mapa.
      </p>
      <p>Os cookies de terceiros seguem as políticas de cada empresa (política de privacidade do Google em policies.google.com/privacy).</p>

      <H>4. Mais informações</H>
      <p>Veja também a nossa Política de Privacidade para saber como tratamos dados pessoais. Dúvidas: WhatsApp {WHATSAPP_LABEL}.</p>
    </div>
  );
}

export function PolicyModal({ isOpen, tab, onTabChange, onClose, onChangeCookiePreferences }: PolicyModalProps) {
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    closeRef.current?.focus();
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = previousOverflow;
    };
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-labelledby="policy-title"
            initial={{ opacity: 0, y: 20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.98 }}
            transition={{ duration: 0.25 }}
            className="relative w-full max-w-2xl max-h-[88vh] flex flex-col bg-[#0F172A] border border-[#D4AF37]/30 rounded-2xl shadow-2xl overflow-hidden"
          >
            <div className="flex items-start justify-between gap-4 p-5 border-b border-slate-800">
              <div>
                <h3 id="policy-title" className="text-xl font-serif font-bold text-white">
                  {tab === 'privacidade' ? 'Política de Privacidade' : 'Política de Cookies'}
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">Última atualização: {UPDATED_AT}</p>
              </div>
              <button
                ref={closeRef}
                type="button"
                onClick={onClose}
                aria-label="Fechar"
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex gap-2 px-5 pt-4" role="tablist">
              {(
                [
                  ['privacidade', 'Privacidade'],
                  ['cookies', 'Cookies'],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  role="tab"
                  aria-selected={tab === id}
                  onClick={() => onTabChange(id)}
                  className={`px-4 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                    tab === id
                      ? 'bg-[#D4AF37]/20 border-[#D4AF37] text-[#F3E5AB]'
                      : 'bg-[#090D16] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="p-5 overflow-y-auto">
              {tab === 'privacidade' ? <PrivacyContent /> : <CookiesContent onChangePreferences={onChangeCookiePreferences} />}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
