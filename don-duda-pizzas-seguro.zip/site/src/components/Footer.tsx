import { Phone, MapPin, Instagram, Heart } from 'lucide-react';

import type { PolicyTab } from './PolicyModal';

interface FooterProps {
  onOpenPolicy: (tab: PolicyTab) => void;
  onResetConsent: () => void;
}

export function Footer({ onOpenPolicy, onResetConsent }: FooterProps) {
  return (
    <footer className="bg-[#05080E] border-t border-slate-900 text-slate-400 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-slate-800/80">
          {/* Brand */}
          <div className="md:col-span-2 space-y-4">
            <a href="#inicio" className="text-2xl font-serif font-bold text-white tracking-tight inline-block">
              Don Duda <span className="text-[#D4AF37]">·</span> Pizzaria
            </a>
            <p className="text-xs sm:text-sm text-slate-400 max-w-md leading-relaxed">
              Pizzas artesanais assadas em forno a lenha napolitano com massa de fermentação lenta 48 horas. A autêntica tradição italiana no coração da Praia da Costa, Vila Velha.
            </p>
            <div className="flex items-center gap-3 pt-1 text-slate-300">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-lg bg-[#0F172A] border border-slate-800 flex items-center justify-center hover:text-[#D4AF37] hover:border-[#D4AF37]/40 transition-colors"
                aria-label="Instagram da Don Duda Pizzas"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://wa.me/5527997794049"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-lg bg-[#0F172A] border border-slate-800 flex items-center justify-center hover:text-emerald-400 hover:border-emerald-500/40 transition-colors"
                aria-label="WhatsApp da Don Duda Pizzas"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-wider text-white font-semibold">Navegação Rápida</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#inicio" className="hover:text-[#F3E5AB] transition-colors">
                  Início
                </a>
              </li>
              <li>
                <a href="#cardapio" className="hover:text-[#F3E5AB] transition-colors">
                  Cardápio Digital Completo
                </a>
              </li>
              <li>
                <a href="#tradicao" className="hover:text-[#F3E5AB] transition-colors">
                  Tradição & Fermentação 48h
                </a>
              </li>
              <li>
                <a href="#localizacao" className="hover:text-[#F3E5AB] transition-colors">
                  Localização na Praia da Costa
                </a>
              </li>
              <li>
                <a href="#contato" className="hover:text-[#F3E5AB] transition-colors">
                  Contato & Reservas
                </a>
              </li>
            </ul>
          </div>

          {/* Contact and Hours */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-wider text-white font-semibold">Atendimento Don Duda</h4>
            <div className="space-y-2.5 text-xs text-slate-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>R. José Pena Medina, 216 - Praia da Costa, Vila Velha - ES, 29101-320</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <a href="tel:+5527997794049" className="hover:text-white transition-colors">
                  +55 27 99779-4049
                </a>
              </div>
              <p className="text-[11px] text-slate-500 pt-1">
                Terça a Domingo das 18:00 às 23:30. Segundas fechado.
              </p>
            </div>
          </div>
        </div>

        {/* Quiet Bottom line */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex flex-col sm:flex-row items-center gap-x-4 gap-y-2">
            <p>© {new Date().getFullYear()} Don Duda Pizzas. Todos os direitos reservados.</p>
            <nav aria-label="Políticas" className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1">
              <button type="button" onClick={() => onOpenPolicy('privacidade')} className="hover:text-[#F3E5AB] underline-offset-2 hover:underline cursor-pointer">
                Política de Privacidade
              </button>
              <button type="button" onClick={() => onOpenPolicy('cookies')} className="hover:text-[#F3E5AB] underline-offset-2 hover:underline cursor-pointer">
                Política de Cookies
              </button>
              <button type="button" onClick={onResetConsent} className="hover:text-[#F3E5AB] underline-offset-2 hover:underline cursor-pointer">
                Preferências de cookies
              </button>
            </nav>
          </div>
          <p className="flex items-center gap-1.5">
            <span>Feito com paixão artesanal em Vila Velha</span>
            <Heart className="w-3.5 h-3.5 text-[#D4AF37] fill-[#D4AF37]" />
          </p>
        </div>
      </div>
    </footer>
  );
}
