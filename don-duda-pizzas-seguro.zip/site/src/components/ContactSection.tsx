import React, { useState } from 'react';
import { LIMITS, cleanPhone, cleanText } from '../lib/sanitize';
import { motion } from 'motion/react';
import { Phone, MessageCircle, MapPin, Calendar, Clock, Send, CheckCircle2 } from 'lucide-react';
import { ReservationFormData } from '../types';

interface ContactSectionProps {
  onOpenPolicy: () => void;
}

export function ContactSection({ onOpenPolicy }: ContactSectionProps) {
  const [formData, setFormData] = useState<ReservationFormData>({
    name: '',
    phone: '',
    type: 'reserva_mesa',
    peopleCount: '2 pessoas',
    date: '',
    time: '19:30',
    notes: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [whatsappUrl, setWhatsappUrl] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const name = cleanText(formData.name, LIMITS.name);
    const phone = cleanPhone(formData.phone);
    const notes = cleanText(formData.notes, LIMITS.notes);

    if (!name || !phone) {
      setErrorMessage('Por favor, preencha seu nome e telefone para contato.');
      return;
    }

    setErrorMessage('');

    // Format message and optionally open WhatsApp directly
    const typeLabel =
      formData.type === 'reserva_mesa'
        ? 'Reserva de Mesa no Salão'
        : formData.type === 'pedido_entrega'
        ? 'Pedido para Entrega'
        : 'Retirada no Balcão';

    const text = `🍕 *SOLICITAÇÃO DE ATENDIMENTO - DON DUDA*\n\n` +
      `*Nome:* ${name}\n` +
      `*Telefone:* ${phone}\n` +
      `*Tipo:* ${typeLabel}\n` +
      (formData.peopleCount ? `*Pessoas:* ${formData.peopleCount}\n` : '') +
      (formData.date ? `*Data:* ${formData.date}\n` : '') +
      (formData.time ? `*Horário:* ${formData.time}\n` : '') +
      (notes ? `*Observações:* ${notes}\n` : '');

    setWhatsappUrl(`https://wa.me/5527997794049?text=${encodeURIComponent(text)}`);
    setSubmitted(true);
  };

  const handleOpenWhatsappFromSuccess = () => {
    window.open(whatsappUrl || 'https://wa.me/5527997794049', '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-24 bg-[#090D16] border-t border-slate-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center mb-16">
          <div className="flex items-center justify-center gap-2 text-xs font-semibold tracking-wider text-[#E6CA65] uppercase mb-2">
            <span>Atendimento Personalizado</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>Vila Velha</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight [text-wrap:balance]">
            Entre em contato ou reserve sua mesa
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            Fale diretamente com nossa equipe para reservas, dúvidas, confraternizações ou encomendas para o seu evento.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left Column: Direct Contact Info Cards */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-2xl bg-[#0F172A] border border-slate-800 space-y-4">
              <h3 className="text-lg font-serif font-bold text-white">Canais Diretos de Contato</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Nosso atendimento telefônico e WhatsApp funciona durante todo o horário de abertura da pizzaria.
              </p>

              <div className="space-y-4 pt-2">
                <a
                  href="https://wa.me/5527997794049?text=Ol%C3%A1%2C+gostaria+de+fazer+um+pedido+na+Don+Duda+Pizzas%21"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-3.5 rounded-xl bg-[#141B2D] border border-slate-800 hover:border-[#D4AF37]/50 transition-all group"
                >
                  <div className="w-10 h-10 rounded-lg bg-emerald-950/70 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-800/40">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block">WhatsApp Oficial</span>
                    <span className="text-sm font-semibold text-white group-hover:text-[#F3E5AB]">
                      (27) 99779-4049
                    </span>
                  </div>
                </a>

                <a
                  href="tel:+5527997794049"
                  className="flex items-center gap-4 p-3.5 rounded-xl bg-[#141B2D] border border-slate-800 hover:border-[#D4AF37]/50 transition-all group"
                >
                  <div className="w-10 h-10 rounded-lg bg-[#090D16] text-[#D4AF37] flex items-center justify-center shrink-0 border border-slate-700/60">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block">Telefone Fixo e Balcão</span>
                    <span className="text-sm font-semibold text-white group-hover:text-[#F3E5AB]">
                      +55 27 99779-4049
                    </span>
                  </div>
                </a>

                <div className="flex items-center gap-4 p-3.5 rounded-xl bg-[#141B2D] border border-slate-800">
                  <div className="w-10 h-10 rounded-lg bg-[#090D16] text-[#D4AF37] flex items-center justify-center shrink-0 border border-slate-700/60">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block">Endereço da Pizzaria</span>
                    <span className="text-sm font-semibold text-white">
                      R. José Pena Medina, 216 - Praia da Costa
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-gradient-to-br from-[#0F172A] to-[#141B2D] border border-[#D4AF37]/20">
              <span className="text-xs uppercase tracking-wider text-[#D4AF37] font-semibold block mb-1">
                Confraternizações & Aniversários
              </span>
              <p className="text-sm text-slate-300 leading-relaxed">
                Planejando um aniversário ou encontro de amigos? Entre em contato com antecedência para reservarmos uma área especial com atendimento dedicado.
              </p>
            </div>
          </div>

          {/* Right Column: Interactive Form */}
          <div className="lg:col-span-7">
            <div className="p-8 rounded-3xl bg-[#0F172A] border border-slate-800 shadow-2xl">
              {submitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-12 text-center space-y-4"
                >
                  <div className="w-16 h-16 rounded-full bg-emerald-950/60 text-emerald-400 border border-emerald-700/40 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-white">
                    Mensagem pronta para enviar!
                  </h3>
                  <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                    Obrigado, <span className="text-white font-semibold">{cleanText(formData.name, LIMITS.name)}</span>! Para concluir, clique no botão abaixo e envie a mensagem pelo WhatsApp. Sua solicitação só chega até nós depois desse envio.
                  </p>

                  <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <button
                      onClick={handleOpenWhatsappFromSuccess}
                      className="w-full sm:w-auto px-6 py-3 rounded-xl font-bold text-[#090D16] bg-gradient-to-r from-[#E6CA65] to-[#D4AF37] hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                    >
                      <MessageCircle className="w-4 h-4 text-[#090D16]" />
                      <span>Enviar pelo WhatsApp</span>
                    </button>
                    <button
                      onClick={() => setSubmitted(false)}
                      className="w-full sm:w-auto px-5 py-3 rounded-xl text-xs font-semibold text-slate-300 hover:text-white border border-slate-700 hover:bg-slate-800/40 transition-colors"
                    >
                      Enviar Outra Mensagem
                    </button>
                  </div>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                        Seu Nome Completo *
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={LIMITS.name}
                        autoComplete="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Ex: Juliana Prado"
                        className="w-full px-4 py-3 bg-[#090D16] border border-slate-700/80 rounded-xl text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37] transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                        Telefone / WhatsApp *
                      </label>
                      <input
                        type="tel"
                        required
                        maxLength={LIMITS.phone}
                        autoComplete="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="(27) 99999-9999"
                        className="w-full px-4 py-3 bg-[#090D16] border border-slate-700/80 rounded-xl text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37] transition-colors"
                      />
                    </div>
                  </div>

                  {/* Purpose Selector */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                      Tipo de Atendimento
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'reserva_mesa', label: 'Reserva Mesa' },
                        { id: 'pedido_entrega', label: 'Delivery' },
                        { id: 'retirada', label: 'Retirada Balcão' },
                      ].map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setFormData({ ...formData, type: item.id as any })}
                          className={`py-2.5 px-3 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                            formData.type === item.id
                              ? 'bg-[#D4AF37]/20 border-[#D4AF37] text-[#F3E5AB]'
                              : 'bg-[#090D16] border-slate-800 text-slate-400 hover:text-white'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {formData.type === 'reserva_mesa' && (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
                            Data
                          </span>
                        </label>
                        <input
                          type="date"
                          value={formData.date}
                          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                          className="w-full px-3 py-2.5 bg-[#090D16] border border-slate-700/80 rounded-xl text-xs text-white focus:outline-none focus:border-[#D4AF37]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                            Horário
                          </span>
                        </label>
                        <select
                          value={formData.time}
                          onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                          className="w-full px-3 py-2.5 bg-[#090D16] border border-slate-700/80 rounded-xl text-xs text-white focus:outline-none focus:border-[#D4AF37]"
                        >
                          <option value="18:30">18:30</option>
                          <option value="19:00">19:00</option>
                          <option value="19:30">19:30</option>
                          <option value="20:00">20:00</option>
                          <option value="20:30">20:30</option>
                          <option value="21:00">21:00</option>
                          <option value="21:30">21:30</option>
                          <option value="22:00">22:00</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                          Nº de Pessoas
                        </label>
                        <select
                          value={formData.peopleCount}
                          onChange={(e) => setFormData({ ...formData, peopleCount: e.target.value })}
                          className="w-full px-3 py-2.5 bg-[#090D16] border border-slate-700/80 rounded-xl text-xs text-white focus:outline-none focus:border-[#D4AF37]"
                        >
                          <option value="2 pessoas">2 pessoas</option>
                          <option value="3 a 4 pessoas">3 a 4 pessoas</option>
                          <option value="5 a 8 pessoas">5 a 8 pessoas</option>
                          <option value="Acima de 8 pessoas">Acima de 8 pessoas</option>
                        </select>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5">
                      Mensagem ou Observações Especiais
                    </label>
                    <textarea
                      rows={3}
                      maxLength={LIMITS.notes}
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      placeholder="Alguma restrição alimentar, comemoração de aniversário ou preferência de mesa?"
                      className="w-full px-4 py-3 bg-[#090D16] border border-slate-700/80 rounded-xl text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37] transition-colors resize-none"
                    />
                  </div>

                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Ao continuar, você concorda com o uso dos dados informados apenas para atender sua solicitação, conforme nossa{' '}
                    <button
                      type="button"
                      onClick={onOpenPolicy}
                      className="underline text-[#E6CA65] hover:text-[#F3E5AB] cursor-pointer"
                    >
                      Política de Privacidade
                    </button>
                    .
                  </p>

                  {errorMessage && (
                    <p className="text-xs text-rose-400 font-medium bg-rose-950/40 border border-rose-800/60 p-3 rounded-lg">
                      {errorMessage}
                    </p>
                  )}

                  <button
                    type="submit"
                    className="w-full py-4 px-6 rounded-xl font-bold text-[#090D16] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#B89225] hover:brightness-110 active:scale-[0.99] transition-all shadow-xl gold-glow flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Send className="w-4 h-4 text-[#090D16]" />
                    <span>Enviar Mensagem & Solicitação</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
