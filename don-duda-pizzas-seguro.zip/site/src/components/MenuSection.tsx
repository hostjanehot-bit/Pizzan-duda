import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Plus, Check, Eye, X, Sparkles } from 'lucide-react';
import { MenuItem } from '../types';
import { MENU_ITEMS } from '../data/menuData';

interface MenuSectionProps {
  onAddToCart: (item: MenuItem, notes?: string) => void;
}

export function MenuSection({ onAddToCart }: MenuSectionProps) {
  const [activeCategory, setActiveCategory] = useState<string>('todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [customNote, setCustomNote] = useState<string>('');
  const [addedNotice, setAddedNotice] = useState<string | null>(null);

  const categories = [
    { id: 'todos', label: 'Todas as Opções' },
    { id: 'tradicionais', label: 'Tradicionais' },
    { id: 'especiais', label: 'Especiais da Casa' },
    { id: 'doces', label: 'Doces' },
    { id: 'bebidas', label: 'Bebidas' },
  ];

  const filteredItems = MENU_ITEMS.filter((item) => {
    const matchesCategory = activeCategory === 'todos' || item.category === activeCategory;
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.ingredients.some((ing) => ing.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const handleQuickAdd = (item: MenuItem) => {
    onAddToCart(item);
    setAddedNotice(item.id);
    setTimeout(() => {
      setAddedNotice((prev) => (prev === item.id ? null : prev));
    }, 1500);
  };

  const handleModalAdd = () => {
    if (selectedItem) {
      onAddToCart(selectedItem, customNote);
      setSelectedItem(null);
      setCustomNote('');
    }
  };

  return (
    <section id="cardapio" className="py-24 bg-[#090D16] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-[#E6CA65] uppercase mb-2">
              <span>Cardápio Digital Don Duda</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Ingredientes de Alta Gastronomia</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight [text-wrap:balance]">
              Pizzas de fermentação lenta e sabores inesquecíveis
            </h2>
            <p className="text-slate-400 text-sm sm:text-base mt-2 max-w-xl">
              Selecione suas opções favoritas para montar seu pedido online e enviar diretamente para a nossa equipe no balcão da Praia da Costa.
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar sabor ou ingrediente..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-[#0F172A] border border-slate-800 rounded-xl text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37]/60 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                aria-label="Limpar busca"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Filter Tabs - Interactive Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 no-scrollbar">
          {categories.map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-5 py-2.5 text-xs sm:text-sm font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-[#E6CA65] to-[#D4AF37] text-[#090D16] shadow-md'
                    : 'bg-[#0F172A] text-slate-300 hover:text-white border border-slate-800/80 hover:border-slate-700'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <motion.div
              key={item.id}
              layout
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="group bg-[#0F172A]/70 rounded-2xl border border-slate-800/80 overflow-hidden hover:border-[#D4AF37]/40 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between shadow-xl"
            >
              <div>
                {/* Image slot with styled fallback container */}
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-900">
                  <img
                    src={item.image}
                    alt={item.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-transparent to-transparent opacity-80" />

                  {/* Highlighting label */}
                  {item.highlight && (
                    <div className="absolute top-3 left-3 bg-[#090D16]/85 backdrop-blur-md px-3 py-1 rounded-md text-[11px] font-medium text-[#F3E5AB] border border-[#D4AF37]/30">
                      {item.highlight}
                    </div>
                  )}

                  {/* Quick View Button */}
                  <button
                    onClick={() => {
                      setSelectedItem(item);
                      setCustomNote('');
                    }}
                    type="button"
                    className="absolute top-3 right-3 p-2 bg-[#090D16]/80 backdrop-blur-md rounded-lg text-slate-200 hover:text-[#D4AF37] opacity-0 group-hover:opacity-100 transition-opacity border border-slate-700/50 cursor-pointer"
                    title="Ver detalhes do prato"
                    aria-label={`Ver detalhes de ${item.name}`}
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>

                {/* Content */}
                <div className="p-6">
                  {/* Clean unboxed metadata */}
                  <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
                    <span className="capitalize">{item.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>Forno 450°C</span>
                    {item.vegetarian && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-emerald-400">Vegetariana</span>
                      </>
                    )}
                    {item.spicy && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-amber-400">Picante suave</span>
                      </>
                    )}
                  </div>

                  <h3 className="text-xl font-serif font-bold text-white mb-2 group-hover:text-[#F3E5AB] transition-colors">
                    {item.name}
                  </h3>

                  <p className="text-slate-300 text-xs sm:text-sm line-clamp-2 leading-relaxed mb-4">
                    {item.description}
                  </p>

                  {/* Ingredients row */}
                  <div className="text-[11px] text-slate-400 leading-normal line-clamp-1">
                    {item.ingredients.join(' · ')}
                  </div>
                </div>
              </div>

              {/* Price & Action Bottom Row */}
              <div className="px-6 py-4 border-t border-slate-800/80 bg-[#090D16]/50 flex items-center justify-between gap-4">
                <div>
                  <span className="text-[11px] text-slate-400 block font-normal">Preço unitário</span>
                  <span className="text-lg sm:text-xl font-serif font-bold text-[#F3E5AB] tabular-nums">
                    R$ {item.price.toFixed(2).replace('.', ',')}
                  </span>
                </div>

                <button
                  onClick={() => handleQuickAdd(item)}
                  type="button"
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                    addedNotice === item.id
                      ? 'bg-emerald-600 text-white'
                      : 'bg-gradient-to-r from-[#E6CA65] to-[#D4AF37] text-[#090D16] hover:brightness-110 active:scale-95 shadow-sm'
                  }`}
                >
                  {addedNotice === item.id ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Adicionado!</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Adicionar</span>
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Empty Search State */}
        {filteredItems.length === 0 && (
          <div className="text-center py-16 bg-[#0F172A]/40 rounded-2xl border border-slate-800 max-w-lg mx-auto">
            <p className="text-lg font-serif text-slate-300 mb-2">Nenhum item encontrado</p>
            <p className="text-sm text-slate-500 mb-6">Tente buscar por outro sabor ou limpe o campo de busca.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setActiveCategory('todos');
              }}
              className="px-5 py-2 text-xs font-semibold text-[#D4AF37] border border-[#D4AF37]/30 rounded-lg hover:bg-[#D4AF37]/10"
            >
              Ver todos os itens do cardápio
            </button>
          </div>
        )}
      </div>

      {/* Pizza Detail Modal */}
      <AnimatePresence>
        {selectedItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0F172A] border border-[#D4AF37]/30 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl"
            >
              <div className="relative aspect-video w-full overflow-hidden">
                <img
                  src={selectedItem.image}
                  alt={selectedItem.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => setSelectedItem(null)}
                  className="absolute top-4 right-4 p-2 bg-[#090D16]/80 text-white rounded-full hover:bg-black transition-colors"
                  aria-label="Fechar janela"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-6">
                <div className="flex items-baseline justify-between mb-2">
                  <h3 className="text-2xl font-serif font-bold text-white">{selectedItem.name}</h3>
                  <span className="text-xl font-serif font-bold text-[#F3E5AB] tabular-nums">
                    R$ {selectedItem.price.toFixed(2).replace('.', ',')}
                  </span>
                </div>

                <p className="text-slate-300 text-sm leading-relaxed mb-4">{selectedItem.description}</p>

                <div className="mb-4">
                  <h4 className="text-xs uppercase tracking-wider text-[#D4AF37] font-semibold mb-2">
                    Ingredientes Selecionados
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedItem.ingredients.map((ing) => (
                      <span
                        key={ing}
                        className="text-xs text-slate-300 bg-[#161F33] px-2.5 py-1 rounded-md border border-slate-700/60"
                      >
                        {ing}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mb-6">
                  <label htmlFor="notes" className="block text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1.5">
                    Observações do pedido (Opcional)
                  </label>
                  <input
                    id="notes"
                    type="text"
                    maxLength={120}
                    value={customNote}
                    onChange={(e) => setCustomNote(e.target.value)}
                    placeholder="Ex: sem orégano, massa bem assada, etc."
                    className="w-full px-3.5 py-2.5 bg-[#090D16] border border-slate-700 rounded-lg text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setSelectedItem(null)}
                    className="flex-1 py-3 text-sm font-medium text-slate-300 hover:text-white border border-slate-700 rounded-xl hover:bg-slate-800/50"
                  >
                    Voltar
                  </button>
                  <button
                    onClick={handleModalAdd}
                    className="flex-1 py-3 text-sm font-bold text-[#090D16] bg-gradient-to-r from-[#E6CA65] to-[#D4AF37] rounded-xl hover:brightness-110 shadow-lg flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-4 h-4 text-[#090D16]" />
                    <span>Adicionar à Sacola</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
