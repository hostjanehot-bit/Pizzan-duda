/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import { MenuItem, CartItem } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { AboutSection } from './components/AboutSection';
import { LocationSection } from './components/LocationSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { OrderDrawer } from './components/OrderDrawer';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';
import { QuickActionModal } from './components/QuickActionModal';
import { CookieBanner } from './components/CookieBanner';
import { PolicyModal, PolicyTab } from './components/PolicyModal';
import { ConsentStatus, clearConsent, loadGoogleFonts, readConsent, saveConsent, unloadGoogleFonts } from './lib/consent';
import { LIMITS, cleanText } from './lib/sanitize';

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isActionModalOpen, setIsActionModalOpen] = useState(false);
  const [consent, setConsent] = useState<ConsentStatus>(() => readConsent());
  const [policyTab, setPolicyTab] = useState<PolicyTab | null>(null);

  // Recursos de terceiros (Google Fonts) só carregam com consentimento.
  useEffect(() => {
    if (consent === 'accepted') loadGoogleFonts();
    else unloadGoogleFonts();
  }, [consent]);

  const handleAcceptConsent = useCallback(() => {
    saveConsent('accepted');
    setConsent('accepted');
  }, []);

  const handleRejectConsent = useCallback(() => {
    saveConsent('rejected');
    setConsent('rejected');
  }, []);

  const handleResetConsent = useCallback(() => {
    clearConsent();
    setConsent('unset');
    setPolicyTab(null);
  }, []);

  const handleClosePolicy = useCallback(() => setPolicyTab(null), []);

  const totalCartCount = cartItems.reduce((acc, current) => acc + current.quantity, 0);

  const handleAddToCart = (item: MenuItem, rawNotes?: string) => {
    const notes = cleanText(rawNotes, LIMITS.itemNote) || undefined;
    setCartItems((prev) => {
      const existingIndex = prev.findIndex((ci) => ci.item.id === item.id);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + 1,
          notes: notes || updated[existingIndex].notes,
        };
        return updated;
      } else {
        return [...prev, { item, quantity: 1, notes }];
      }
    });
  };

  const handleUpdateQuantity = (itemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(itemId);
      return;
    }
    setCartItems((prev) =>
      prev.map((ci) => (ci.item.id === itemId ? { ...ci, quantity: newQty } : ci))
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setCartItems((prev) => prev.filter((ci) => ci.item.id !== itemId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleOpenPrimaryAction = () => {
    if (cartItems.length > 0) {
      setIsCartOpen(true);
    } else {
      setIsActionModalOpen(true);
    }
  };

  const handleScrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#090D16] text-slate-100 flex flex-col font-sans selection:bg-[#D4AF37]/30 selection:text-[#F3E5AB]">
      {/* Top Bar Navigation */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenOrderModal={handleOpenPrimaryAction}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Início / Hero */}
        <Hero onOpenOrderModal={handleOpenPrimaryAction} />

        {/* 2. Cardápio Digital Interativo */}
        <MenuSection onAddToCart={handleAddToCart} />

        {/* 3. Nossa História / Tradição */}
        <AboutSection />

        {/* 4. Localização & Ambiente na Praia da Costa */}
        <LocationSection mapsAllowed={consent === 'accepted'} onAllowMaps={handleAcceptConsent} />

        {/* 5. Contato & Reservas */}
        <ContactSection onOpenPolicy={() => setPolicyTab('privacidade')} />
      </main>

      {/* Footer */}
      <Footer onOpenPolicy={setPolicyTab} onResetConsent={handleResetConsent} />

      {/* WhatsApp Floating Button */}
      <WhatsAppFloatingButton />

      {/* Digital Order / Cart Drawer */}
      <OrderDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onOpenPolicy={() => setPolicyTab('privacidade')}
      />

      {/* Quick Action Decision Modal */}
      <QuickActionModal
        isOpen={isActionModalOpen}
        onClose={() => setIsActionModalOpen(false)}
        onGoToMenu={() => handleScrollToSection('cardapio')}
        onGoToContact={() => handleScrollToSection('contato')}
      />

      <CookieBanner
        visible={consent === 'unset' && policyTab === null}
        onAccept={handleAcceptConsent}
        onReject={handleRejectConsent}
        onOpenPolicy={() => setPolicyTab('cookies')}
      />

      <PolicyModal
        isOpen={policyTab !== null}
        tab={policyTab ?? 'privacidade'}
        onTabChange={setPolicyTab}
        onClose={handleClosePolicy}
        onChangeCookiePreferences={handleResetConsent}
      />
    </div>
  );
}
