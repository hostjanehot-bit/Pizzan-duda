# Don Duda Pizzas – site

Site estático (React + Vite + Tailwind). Não tem backend nem banco de dados: os pedidos e reservas são montados no navegador e enviados pelo WhatsApp.

## Rodar localmente

```
npm install
npm run dev
```

## Publicar

```
npm run build   # gera a pasta dist/
```

Publique o conteúdo de `dist/` em uma hospedagem com HTTPS (Netlify, Vercel, Cloudflare Pages, nginx…).

## Segurança

- **Cabeçalhos HTTP (CSP, HSTS etc.)**: `public/_headers` (Netlify / Cloudflare Pages), `vercel.json` (Vercel) ou `deploy/nginx-security-headers.conf` (nginx). Use só o que corresponde à sua hospedagem.
- Fonte do Google e mapa só carregam após o aceite do aviso de cookies (`src/lib/consent.ts`).
- Todo texto digitado pelo cliente é limpo e limitado em tamanho antes de entrar na mensagem do WhatsApp (`src/lib/sanitize.ts`).
- Rode `npm audit` de tempos em tempos e mantenha as dependências atualizadas.

## Privacidade

As políticas de Privacidade e de Cookies estão em `src/components/PolicyModal.tsx`. **Antes de publicar, revise o texto** e acrescente a razão social/CNPJ e um e-mail de contato, se houver. Se adicionar Google Analytics, Meta Pixel ou qualquer outro rastreador, atualize as políticas e o aviso de cookies.
